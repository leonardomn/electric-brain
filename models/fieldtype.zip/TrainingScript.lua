require('torch')
require('nn')
require('nngraph')
require('rnn')
require('optim')
require('mime')
require('image')
local _ = require('underscore')
cjson = require('cjson')
local JSON = require('./JSON')
require('./Debug')
require('./WrapDebug')
require('./WrapTable')
require('FieldtypeCsvModule')
require('FieldtypeCsvCriterion')

-- Define our object, TrainingScript.
-- Do not change the name of this class!
local TrainingScript = {}
TrainingScript.__index = TrainingScript


-- Creates the TrainingScript object.
-- Do not change the name of this class
function TrainingScript.new()
    local self = {}

    setmetatable(self, TrainingScript)

    -- Connect to the other nodes in the process
    self.ipctree = require 'ipc.LocalhostTree'(tonumber(arg[1]), tonumber(arg[2]))
    self.allReduceSGD = require 'distlearn.AllReduceSGD'(self.ipctree)

    -- generate SVG of the graph with the problem node highlighted
    -- and hover over the nodes in svg to see the filename:line_number info
    -- nodes will be annotated with local variable names even if debug mode is not enabled.
    nngraph.setDebug(true)

    -- Increase the stack limit
    --print(coroutine)
    --local olddefault = coroutine.cstacksize(268435456)

    -- This is a table where we will store loaded data entries
    self.dataEntries = {}

    -- Create the main neural network module
    self.module = nn.FieldtypeCsvModule(self)

    -- Create a copy of the main neural network module that will be used for saving
    self.moduleSaveCopy = nn.FieldtypeCsvModule(self)

    -- Create the main criterion for training
    self.criterion = nn.FieldtypeCsvCriterion(self)

    -- Prepare the parameters
    self.params, self.gradParams = self.module:getParameters()

    return self
end


function TrainingScript:evaluateTrainingIteration(batch)
    local optimState = {}

    local iteration = function(params)
        --if params_ ~= self.params then
        --    self.params:copy(params_)
        --end
        self.gradParams:zero()

        local expectedOutputs = {}
        local loss = 0

        ------------------- forward pass -------------------
        self.module:training()

        local batchOutputs = self.module:forward(batch.input)
        loss = loss + self.criterion:forward(batchOutputs, batch.output)

        ------------------- backward pass -------------------
        local criterionDerivatives = self.criterion:backward(batchOutputs, batch.output)
        local inputDerivatives = self.module:backward(batch.input, criterionDerivatives)

        -- clip gradient element-wise
        self.gradParams:clamp(-5, 5)

        -- Gather the grads from all nodes
        self.allReduceSGD.sumAndNormalizeGradients({self.gradParams})

        return loss, self.gradParams
    end

    local _ignore, loss
    _ignore, loss = optim.adamax(iteration, self.params, optimState)

    -- Collect gabarge at the end of each iteration - prevents build up of useless memory
    collectgarbage()

    -- Keep track of the training accuracy
    --table.insert(previousAccuracies, self.lastIterationTrainingAccuracy)

    return {
        loss = loss[1]
    }
end


function TrainingScript:evaluateBatch(batch)
    ------------------- forward pass -------------------
    self.module:evaluate()

    local batchOutputs = self.module:forward(batch.input)
    return self:unwindBatchOutput(batchOutputs)
end

-- Prepares a batch composed of the given data points
function TrainingScript:prepareBatch(samples)
    local batch = {}

    local samples1 = {}
    for k,v in pairs(samples) do
        table.insert(samples1, self.dataEntries[v].input)
    end

    



    local batch1 = {}




    batch1[1] = {}
    -- First determine what the longest sequence is
    local longest = 0
    for k,v in pairs(samples1) do
        if #samples1[k] >= 1 then
            longest = math.max(longest, #samples1[k][1])
        end
    end

    -- Prepare the items for each entry
    for n = 1, longest do
        local samples2 = {}
        for k,v in pairs(samples1) do
            if #samples1[k] >= 1 and #samples1[k][1] >= n then
                -- Insert an actual sample
                table.insert(samples2, samples1[k][1][n])
            else
                -- Insert a blank object
                table.insert(samples2, {})
            end
        end

        



    local batch2 = {}

    batch2[1] = torch.zeros(1, #samples, 128)
    for k,v in pairs(samples2) do
        if #samples2[k] >= 1 then
            batch2[1]:narrow(2, k, 1):copy(samples2[k][1])
        end
    end







    


        table.insert(batch1[1], batch2)
    end





    batch.input = batch1

    samples1 = {}
    for k,v in pairs(samples) do
        table.insert(samples1, self.dataEntries[v].output)
    end
    



    local batch1 = {}

    batch1[1] = torch.zeros(1, #samples, 33)
    for k,v in pairs(samples1) do
        if #samples1[k] >= 1 then
            batch1[1]:narrow(2, k, 1):copy(samples1[k][1])
        end
    end







    

    


    batch.output = batch1

    return batch
end


-- Unwinds a given batch output, separating its outputs composed of the given data points
function TrainingScript:unwindBatchOutput(batch1)
    



    local output1 = {}
    local entries = batch1[1]:size()[2]
    for s=1,entries do
        output1[s] = {}

    
        output1[s][1] = torch.zeros(1, 1, 33)
        output1[s][1]:copy(batch1[1]:narrow(2, s, 1))
    


    
    end
    return output1
end


-- This method converts a piece of input data from object format into Torch Tensor format.
function TrainingScript:convertInputIn(data1)
    


    local transformed1 = {}
    



    transformed1[1] = {}
    for n = 1, #data1["value"] do
        local data2 = data1["value"][n]

        


    local transformed2 = {}
    
        transformed2[1] = torch.zeros(1, 1, 128)
    


    
        
            transformed2[1][1][1][1 + data2["character"]] = 1
        
        
    
    



    


        table.insert(transformed1[1], transformed2)
    end


    return transformed1
end


-- This method converts a piece of output data from object format into Torch Tensor format.
function TrainingScript:convertOutputIn(data1)
    


    local transformed1 = {}
    
        transformed1[1] = torch.zeros(1, 1, 33)
    


    
        
            transformed1[1][1][1][1 + data1["condensedType"]] = 1
        
        
    
    

    
        
            transformed1[1][1][1][12 + data1["type"]] = 1
        
        
    
    



    

    

    return transformed1
end


-- This method converts a piece of input data from Torch Tensor format back into regular object format
function TrainingScript:convertInputOut(data1)
    


    local transformed1 = {}



    transformed1.value = {}
    for n = 1, #data1[1] do
        local data2 = data1[1][n]

        


    local transformed2 = {}


    
        
            local probs, index = torch.max(data2[1]:narrow(3, 1, 128)[1][1], 1)
            transformed2["character"] = index[1] - 1
        
        
    
    




        table.insert(transformed1.value, transformed2)
    end


    return transformed1
end


-- This method converts a piece of output data from Torch Tensor format back into regular object format
function TrainingScript:convertOutputOut(data1)
    


    local transformed1 = {}


    
        
            local probs, index = torch.max(data1[1]:narrow(3, 1, 11)[1][1], 1)
            transformed1["condensedType"] = index[1] - 1
        
        
    
    

    
        
            local probs, index = torch.max(data1[1]:narrow(3, 12, 22)[1][1], 1)
            transformed1["type"] = index[1] - 1
        
        
    
    



    return transformed1
end


-- This method can be used to send a log message upwards to Electric Brain, which
-- will be visible on the ElectricBrain interface. Useful for debugging.
function TrainingScript:log(message)
    local stackInfo = debug.getinfo(2, 'fSl')
    if stackInfo.func == print then
        stackInfo = debug.getinfo(3, 'fSl')
    end

    local response = {
        type = "log"
    }

    if torch.type(message) == 'string' then
        response.message = message
    else
        response.message = JSON:encode(message, {}, {
           pretty = true,
           indent = "   ",
           align_keys = false,
        })

        if not response.message then
            response.message = tostring(message)
        end
    end

    response.message = stackInfo.source .. ":" .. stackInfo.currentline .. "  " .. response.message

    self:sendResponse(response)
end


-- This method sends a message to the ElectricBrain manager process.
function TrainingScript:sendResponse(response)
    io.write(cjson.encode(response) .. "\n")
    io.flush()
end

-- This is the main loop which communicates with the manager process in Electric Brain code.
-- Its generally best not to change this too much.
function TrainingScript:enterTrainingLoop()
    -- Now start waiting for messages from standard input
    repeat
        local commandString = io.read("*line")
        local command = cjson.decode(commandString)
        if command then
            if command.type == "handshake" then
                -- Send back a handshake response
                self:sendResponse({type = "handshake"})
            elseif command.type == "reset" then
                -- Resets the model with randomly generated parameters
                self.params:uniform(-0.08, 0.08)
                self.gradParams:zero()
                self:sendResponse({type = "resetCompleted"})
            elseif command.type == "iteration" then
                -- The iteration command advances the network with one forward and backward pass.
                -- It will use data references in an array called 'samples'. These samples must
                -- have been previously loaded into memory using the 'store' command'
                local batch = self:prepareBatch(command.samples)
                local results = self:evaluateTrainingIteration(batch)
                results.type = "iterationCompleted"
                self:sendResponse(results)
            elseif command.type == "store" then
                -- The store command is used by the manager process to store a specific data entry for
                -- quick retrieval later. Then data is provided directly inside the JSON object of
                -- the command. It is then prepared by conversion to Torch tensors as needed.

                self.dataEntries[command.id] = {
                    input = self:convertInputIn(command.input),
                    output = self:convertOutputIn(command.output)
                }

                self:sendResponse({type="stored"})
            elseif command.type == "stats" then
                -- The 'stats' command is used to provide statistics up to the surrounding manager
                -- code

                -- Start with garbage collection, so we don't count anything we don't want

                collectgarbage('collect')
                local stats = {
                    memoryUsage = collectgarbage('count')
                }

                self:sendResponse({type="stats", stats = stats})
            elseif command.type == 'forget' then
                -- The forget command is used by the manager process to indicate to forget a particular
                -- data entry. We do this to manage the amount of memory used by the process.

                self.dataEntries[command.id] = nil
                self:sendResponse({type="forgotten"})
            elseif command.type == "evaluate" then
                -- The evaluate command runs an object through the network and
                -- return the result
                local batch = self:prepareBatch(command.samples)
                local results = self:evaluateBatch(batch)

                local convertedResults = {}
                for n = 1,#results do
                    local id = command.samples[n]
                    local result = results[n]
                    local converted = self:convertOutputOut(result)
                    converted.id = id
                    table.insert(convertedResults, converted)
                end

                local response = {
                    type = "evaluationCompleted",
                    objects = convertedResults
                }
                self:sendResponse(response)
            elseif command.type == "save" then
                -- The save command causes the process to save the trained model out to disk
                self.moduleSaveCopy:getParameters():copy(self.params)
                torch.save("model.t7", self.moduleSaveCopy)
                local response = {type = "saved"}
                self:sendResponse(response)
            elseif command.type == "load" then
                -- The load command causes the process to load the trained model from the disk
                self.module = torch.load("model.t7")
                self.moduleSaveCopy = torch.load("model.t7")
                self.params, self.gradParams = self.module:getParameters()
                local response = {type = "loaded"}
                self:sendResponse(response)
            elseif command.type == "synchronize" then
                -- The synchronize command forces the process to synchronize its parameters with other processes
                self.allReduceSGD.synchronizeParameters({self.params})
                local response = {type = "synchronized"}
                self:sendResponse(response)
            end

        end
    until false == true -- Repeat forever. For some reason, the simple while True: doesn't actually work in Lua.
end

local script = TrainingScript.new()

-- Override the print function
print = function(message)
    script:log(message)
end

script:enterTrainingLoop()
