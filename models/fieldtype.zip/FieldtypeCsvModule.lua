require('torch')
require('nn')
require('nngraph')
if not nn.MapTable then
    require('MapTable')
end
require('MergeSequences')
require('MergeFixedIntoSequence')
require('SeqBGRU')


require('FieldtypeCsvModule__value')


local FieldtypeCsvModule, parent = torch.class('nn.FieldtypeCsvModule', 'nn.Container')

function FieldtypeCsvModule:__init()
    parent.__init(self)

    -- Build up the graph of neural network modules
    local FieldtypeCsvModule_input = nn.Identity()()
    local value_selectSequenceNode = nn.SelectTable(1)(FieldtypeCsvModule_input)
    local value_subModuleNode = nn.Identity()(value_selectSequenceNode)
    local value_prepareRNNInputs = nn.MapTable(nn.SelectTable(1))(value_subModuleNode)
    local value_fuseRNNInputTensors = nn.Sequential()
        :add(nn.JoinTable(1))
    (value_prepareRNNInputs)
    local value_rnnNode = nn.Sequential()
        :add(nn.SeqBRNN(128, 100))
        :add(nn.SeqBRNN(100, 100))
        :add(nn.Dropout(0.5))
    (value_fuseRNNInputTensors)
    local value_fixedResultNode = nn.Sequential()
        :add(nn.Sum(1))
        :add(nn.Linear(100, 50))
        :add(nn.Unsqueeze(1))
    (value_rnnNode)
    local joinedFixedTensorNode = nn.Identity()(value_fixedResultNode)
    local reshapedJoinedTensor = nn.Select(1, 1)(joinedFixedTensorNode)
    local linearUnit = nn.Linear(50, 11)(reshapedJoinedTensor)
    local extract_condensedType = nn.Narrow(2, 1, 11)(linearUnit)
    local softmax_condensedType = nn.LogSoftMax()(extract_condensedType)
    local output_condensedType = nn.Unsqueeze(1)(softmax_condensedType)
    local fixedOutputNode = nn.Identity()(output_condensedType)
    local FieldtypeCsvModule_outputs = nn.WrapTable()(fixedOutputNode)


    -- Add in the annotations. We do this afterwards so that the above code is more readable.
    FieldtypeCsvModule_input:annotate({name="FieldtypeCsvModule_input"})
    value_selectSequenceNode:annotate({name="value_selectSequenceNode"})
    value_subModuleNode:annotate({name="value_subModuleNode"})
    value_prepareRNNInputs:annotate({name="value_prepareRNNInputs"})
    value_fuseRNNInputTensors:annotate({name="value_fuseRNNInputTensors"})
    value_rnnNode:annotate({name="value_rnnNode"})
    value_fixedResultNode:annotate({name="value_fixedResultNode"})
    joinedFixedTensorNode:annotate({name="joinedFixedTensorNode"})
    reshapedJoinedTensor:annotate({name="reshapedJoinedTensor"})
    linearUnit:annotate({name="linearUnit"})
    extract_condensedType:annotate({name="extract_condensedType"})
    softmax_condensedType:annotate({name="softmax_condensedType"})
    output_condensedType:annotate({name="output_condensedType"})
    fixedOutputNode:annotate({name="fixedOutputNode"})
    FieldtypeCsvModule_outputs:annotate({name="FieldtypeCsvModule_outputs"})


    local module = nn.gModule({FieldtypeCsvModule_input}, {FieldtypeCsvModule_outputs})

    -- Store the module
    self.module = module;

    -- Output a graph svg file of the module
    graph.dot(module.fg, 'FieldtypeCsvModule', 'FieldtypeCsvModule')

    -- so that it can be handled like a Container
    self:add(self.module)

    -- Create an output table with at least a fixed Tensor
    self.output = {torch.Tensor()}
end


function FieldtypeCsvModule:updateOutput(input)
    self.output = self.module:updateOutput(input)
    return self.output
end

function FieldtypeCsvModule:updateGradInput(input, gradOutput)
    self.gradInput = self.module:updateGradInput(input, gradOutput)
    return self.gradInput
end

function FieldtypeCsvModule:accGradParameters(input, gradOutput, scale)
    self.module:accGradParameters(input, gradOutput, scale)
end

function FieldtypeCsvModule:accUpdateGradParameters(input, gradOutput, lr)
    self.module:accUpdateGradParameters(input, gradOutput, lr)
end

function FieldtypeCsvModule:sharedAccUpdateGradParameters(input, gradOutput, lr)
    self.module:sharedAccUpdateGradParameters(input, gradOutput, lr)
end

function FieldtypeCsvModule:__tostring__()
    if self.module.__tostring__ then
        return torch.type(self) .. ' @ ' .. self.module:__tostring__()
    else
        return torch.type(self) .. ' @ ' .. torch.type(self.module)
    end
end
