require('torch')
require('nn')







local FieldtypeCsvCriterion, parent = torch.class('nn.FieldtypeCsvCriterion', 'nn.Criterion')

function FieldtypeCsvCriterion:__init(trainingScript)
    parent.__init(self)

    -- Create a criterion for each field on the output
    self.criterions = {}
    self.sequenceCriterions = {}
    
    
        
            local fieldCriterion = nn.ClassNLLCriterion()
            self.criterions.condensedType = fieldCriterion
        
        
    

    self.output = 0
    self.gradInput = {}
end


function FieldtypeCsvCriterion:updateOutput(input, target)
   self.output = 0


   
   
   for n=1,input[1]:size()[2] do
        local inputTensor_condensedType = input[1][1][n]:narrow(1, 1, 11)

        
        local targetTensor_condensedType = target[1][1][n]:narrow(1, 1, 11):nonzero()[1]
        
        

        self.output = self.output + self.criterions.condensedType:updateOutput(inputTensor_condensedType, targetTensor_condensedType:double())
        
   end
   
   
   return self.output
end


function FieldtypeCsvCriterion:updateGradInput(input, target)
   self.gradInput = {
        
        torch.zeros(input[1]:size())
        
   }
   
   
   for n=1,input[1]:size()[2] do
       local inputTensor_condensedType = input[1][1][n]:narrow(1, 1, 11)

       
       local targetTensor_condensedType = target[1][1][n]:narrow(1, 1, 11):nonzero()[1]
       
       

       local gradInput_condensedType = self.criterions.condensedType:updateGradInput(inputTensor_condensedType, targetTensor_condensedType:double())

       self.gradInput[1][1][n]:narrow(1, 1, 11):copy(gradInput_condensedType)
       
   end
   
   

   return self.gradInput
end


function FieldtypeCsvCriterion:type(type, tensorCache)
   self.gradInput = {}
   return parent.type(self, type, tensorCache)
end
